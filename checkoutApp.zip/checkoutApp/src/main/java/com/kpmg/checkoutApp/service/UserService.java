package com.kpmg.checkoutApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kpmg.checkoutApp.model.User;
import com.kpmg.checkoutApp.repository.UserRepo;

import jakarta.transaction.Transactional;

@Service
public class UserService {
	
	
	@Autowired
	private UserRepo userRepo;
	
	@Transactional
	public User saveUser(User user) {
		return userRepo.save(user);
	}

}
