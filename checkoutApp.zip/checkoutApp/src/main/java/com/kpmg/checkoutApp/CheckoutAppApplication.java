package com.kpmg.checkoutApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheckoutAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CheckoutAppApplication.class, args);
	}

}
