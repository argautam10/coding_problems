package com.kpmg.checkoutApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kpmg.checkoutApp.model.User;
import com.kpmg.checkoutApp.service.UserService;

@RestController
@RequestMapping("/new_table")
public class Controller {
	
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/create")
	public User createUser(@RequestBody User user) {
		return userService.saveUser(user); 
	}

}
